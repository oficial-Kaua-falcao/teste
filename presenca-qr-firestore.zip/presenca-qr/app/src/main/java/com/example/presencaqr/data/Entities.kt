package com.example.presencaqr.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "events")
data class Event(@PrimaryKey val id: String, val name: String, val date: String?, val description: String?, val createdAt: Long)

@Entity(tableName = "participants", foreignKeys = [ForeignKey(entity = Event::class, parentColumns = ["id"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE)], indices = [Index("eventId"), Index(value = ["token"], unique = true)])
data class Participant(@PrimaryKey val id: String, val eventId: String, val name: String, val token: String, val createdAt: Long)

@Entity(tableName = "attendances", foreignKeys = [ForeignKey(entity = Event::class, parentColumns = ["id"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE), ForeignKey(entity = Participant::class, parentColumns = ["id"], childColumns = ["participantId"], onDelete = ForeignKey.CASCADE)], indices = [Index(value = ["eventId", "participantId"], unique = true), Index("token")])
data class Attendance(@PrimaryKey val id: String, val participantId: String, val eventId: String, val token: String, val confirmedAt: Long, val state: String = "CONFIRMED")

data class ParticipantReport(val participant: Participant, val attendance: Attendance?)

@Dao interface EventDao {
    @Query("SELECT * FROM events ORDER BY createdAt DESC") fun observeAll(): Flow<List<Event>>
    @Query("SELECT * FROM events WHERE id = :id") suspend fun get(id: String): Event?
    @Insert suspend fun insert(event: Event)
    @Update suspend fun update(event: Event)
    @Delete suspend fun delete(event: Event)
}

@Dao interface ParticipantDao {
    @Query("SELECT * FROM participants WHERE eventId = :eventId ORDER BY name COLLATE NOCASE") fun observeForEvent(eventId: String): Flow<List<Participant>>
    @Query("SELECT * FROM participants WHERE token = :token LIMIT 1") suspend fun byToken(token: String): Participant?
    @Query("SELECT * FROM participants WHERE id = :id LIMIT 1") suspend fun byId(id: String): Participant?
    @Insert suspend fun insert(participant: Participant)
}

@Dao interface AttendanceDao {
    @Query("SELECT * FROM attendances WHERE eventId = :eventId") fun observeForEvent(eventId: String): Flow<List<Attendance>>
    @Query("SELECT * FROM attendances WHERE eventId = :eventId AND participantId = :participantId LIMIT 1") suspend fun find(eventId: String, participantId: String): Attendance?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(attendance: Attendance): Long
}
