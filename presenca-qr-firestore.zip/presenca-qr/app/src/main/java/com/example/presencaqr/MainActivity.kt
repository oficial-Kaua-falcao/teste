package com.example.presencaqr

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.presencaqr.data.*
import com.example.presencaqr.scanner.QrScannerView
import com.example.presencaqr.ui.EVENT_QR_PREFIX
import com.example.presencaqr.ui.eventQrPayload
import com.example.presencaqr.ui.makeQrBitmap
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class CloudViewModel : ViewModel() {
    private val repo = FirestoreRepository()
    var profile by mutableStateOf<CloudUser?>(null)
    var events by mutableStateOf<List<CloudEvent>>(emptyList())
    var selected by mutableStateOf<CloudEvent?>(null)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)

    init { viewModelScope.launch { try { profile = repo.currentProfile(); if (profile != null) repo.observeEvents().collect { events = it } } catch (e: Exception) { error = friendly(e) } } }
    fun register(name: String, done: () -> Unit) { busy = true; viewModelScope.launch { try { profile = repo.signInAndSaveName(name); message = "Cadastro concluído."; launch { repo.observeEvents().collect { events = it } }; done() } catch (e: Exception) { error = friendly(e) } finally { busy = false } } }
    fun create(name: String, date: String, description: String, done: () -> Unit) { busy = true; viewModelScope.launch { try { selected = repo.createEvent(name, date, description); message = "Evento criado e sincronizado."; done() } catch (e: Exception) { error = friendly(e) } finally { busy = false } } }
    fun join(code: String, done: () -> Unit) { busy = true; viewModelScope.launch { try { selected = repo.joinEvent(code); message = "Você entrou no evento."; done() } catch (e: Exception) { error = friendly(e) } finally { busy = false } } }
    fun joinQr(payload: String, done: () -> Unit) { if (!payload.startsWith(EVENT_QR_PREFIX)) { error = "Este QR Code não é um convite de evento."; return }; join(payload.removePrefix(EVENT_QR_PREFIX), done) }
    fun confirmPresence(eventId: String) { busy = true; viewModelScope.launch { try { message = if (repo.confirmMyPresence(eventId)) "Presença registrada no Firestore." else "Presença já confirmada neste evento." } catch (e: Exception) { error = friendly(e) } finally { busy = false } } }
    private fun friendly(e: Exception): String = e.message ?: "Não foi possível comunicar com o Firebase. Verifique a internet."
}

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF2457A6))) { CloudApp() } } } }

@Composable fun CloudApp(vm: CloudViewModel = viewModel()) {
    var screen by remember { mutableStateOf("home") }
    var showCreate by remember { mutableStateOf(false) }
    var showJoin by remember { mutableStateOf(false) }
    var qrPayload by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    if (vm.profile == null) RegistrationScreen(vm)
    else when (screen) {
        "home" -> HomeCloudScreen(vm, onCreate = { showCreate = true }, onJoin = { showJoin = true }, onScan = { screen = "scan" }, onSelect = { vm.selected = it; screen = "event" })
        "event" -> vm.selected?.let { EventCloudScreen(vm, it, onBack = { screen = "home" }, onQr = { qrPayload = eventQrPayload(it.id); screen = "qr" }) }
        "qr" -> qrPayload?.let { CloudQrScreen(it, onBack = { screen = "event" }) }
        "scan" -> QrScannerView(onBack = { screen = "home" }, onResult = { value -> vm.joinQr(value) { screen = "home" }; Toast.makeText(context, "Processando convite do evento…", Toast.LENGTH_SHORT).show() })
    }
    if (showCreate) CreateCloudDialog(vm, onDismiss = { showCreate = false })
    if (showJoin) JoinCloudDialog(vm, onDismiss = { showJoin = false })
    vm.message?.let { msg -> AlertDialog(onDismissRequest = { vm.message = null }, confirmButton = { TextButton({ vm.message = null }) { Text("OK") } }, text = { Text(msg) }) }
    vm.error?.let { msg -> AlertDialog(onDismissRequest = { vm.error = null }, confirmButton = { TextButton({ vm.error = null }) { Text("OK") } }, title = { Text("Atenção") }, text = { Text(msg) }) }
}

@Composable fun RegistrationScreen(vm: CloudViewModel) { var name by remember { mutableStateOf("") }; Scaffold(topBar = { TopAppBar(title = { Text("Presença QR") }) }) { p -> Column(Modifier.padding(p).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) { Text("Antes de continuar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Informe seu nome para entrar em eventos e registrar sua presença em qualquer dispositivo."); OutlinedTextField(name, { name = it }, label = { Text("Seu nome") }, singleLine = true, Modifier.fillMaxWidth()); Button(onClick = { vm.register(name) {} }, enabled = name.trim().length >= 2 && !vm.busy, Modifier.fillMaxWidth()) { Text(if (vm.busy) "Conectando…" else "Entrar") } } } }

@Composable fun HomeCloudScreen(vm: CloudViewModel, onCreate: () -> Unit, onJoin: () -> Unit, onScan: () -> Unit, onSelect: (CloudEvent) -> Unit) { Scaffold(topBar = { TopAppBar(title = { Text("Meus eventos") }) }, floatingActionButton = { FloatingActionButton(onClick = onCreate) { Text("+") } }) { p -> Column(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Olá, ${vm.profile?.name}", style = MaterialTheme.typography.titleLarge); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = onJoin, Modifier.weight(1f)) { Text("Entrar por código") }; OutlinedButton(onClick = onScan, Modifier.weight(1f)) { Text("Ler convite QR") } }; Text("Eventos sincronizados pela internet", style = MaterialTheme.typography.labelLarge); if (vm.events.isEmpty()) Text("Nenhum evento encontrado. Crie um evento ou entre usando o código recebido.", Modifier.padding(vertical = 24.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(vm.events) { e -> Card(Modifier.fillMaxWidth().clickable { onSelect(e) }) { Column(Modifier.padding(16.dp)) { Text(e.name, style = MaterialTheme.typography.titleLarge); Text(e.date ?: "Data não informada"); Text(if (e.creatorId == vm.profile?.id) "Organizador" else "Participante") } } } } } } }

@Composable fun CreateCloudDialog(vm: CloudViewModel, onDismiss: () -> Unit) { var name by remember { mutableStateOf("") }; var date by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = onDismiss, title = { Text("Criar evento") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("Nome") }); OutlinedTextField(date, { date = it }, label = { Text("Data") }); OutlinedTextField(desc, { desc = it }, label = { Text("Descrição") }) } }, confirmButton = { TextButton(enabled = name.isNotBlank() && !vm.busy, onClick = { vm.create(name, date, desc) { onDismiss() } }) { Text("Criar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }) }

@Composable fun JoinCloudDialog(vm: CloudViewModel, onDismiss: () -> Unit) { var code by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = onDismiss, title = { Text("Entrar em evento") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Cole o event_id recebido do organizador."); OutlinedTextField(code, { code = it }, label = { Text("Código do evento") }, singleLine = true) } }, confirmButton = { TextButton(enabled = code.isNotBlank() && !vm.busy, onClick = { vm.join(code) { onDismiss() } }) { Text("Entrar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }) }

@Composable fun EventCloudScreen(vm: CloudViewModel, event: CloudEvent, onBack: () -> Unit, onQr: () -> Unit) { val repo = remember { FirestoreRepository() }; val members by repo.observeMembers(event.id).collectAsState(initial = emptyList()); val attendances by repo.observeAttendances(event.id).collectAsState(initial = emptyList()); Scaffold(topBar = { TopAppBar(title = { Text(event.name) }, navigationIcon = { TextButton(onClick = onBack) { Text("Voltar") } }) }) { p -> Column(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text(event.description ?: ""); Text("Participantes: ${members.size} · Presentes: ${attendances.size}"); Button(onClick = onQr, Modifier.fillMaxWidth()) { Text("Criar convite QR do evento") }; Button(onClick = { vm.confirmPresence(event.id) }, enabled = !vm.busy, Modifier.fillMaxWidth()) { Text("Confirmar minha presença") }; Text("Participantes sincronizados", style = MaterialTheme.typography.titleMedium); LazyColumn { items(members) { member -> val confirmed = attendances.any { it.userId == member.id }; ListItem(headlineContent = { Text(member.name) }, supportingContent = { Text(if (confirmed) "Presença confirmada" else "Pendente") }) } } } } }

@Composable fun CloudQrScreen(payload: String, onBack: () -> Unit) { val context = LocalContext.current; val bitmap = remember(payload) { makeQrBitmap(payload) }; Scaffold(topBar = { TopAppBar(title = { Text("Convite do evento") }, navigationIcon = { TextButton(onClick = onBack) { Text("Voltar") } }) }) { p -> Column(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Image(bitmap.asImageBitmap(), "QR Code do evento", Modifier.fillMaxWidth().aspectRatio(1f)); Text("Mostre ou compartilhe este QR Code. A outra pessoa poderá lê-lo no próprio aparelho e entrar no evento pelo Firestore."); Button(onClick = { shareBitmap(context, bitmap) }, Modifier.fillMaxWidth()) { Text("Compartilhar convite") } } } }

private fun shareBitmap(context: Context, bitmap: Bitmap) { val file = File(context.cacheDir, "convite-evento-${System.currentTimeMillis()}.png"); FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file); val intent = Intent(Intent.ACTION_SEND).apply { type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }; context.startActivity(Intent.createChooser(intent, "Compartilhar convite")) }
