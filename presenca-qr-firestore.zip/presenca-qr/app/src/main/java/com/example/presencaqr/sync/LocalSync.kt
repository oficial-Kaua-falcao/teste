package com.example.presencaqr.sync

import com.example.presencaqr.data.AttendanceRepository
import kotlinx.coroutines.*
import java.io.*
import java.net.*

class LocalSyncServer(private val repository: AttendanceRepository, private val port: Int = 45678) {
    private var server: ServerSocket? = null
    private var job: Job? = null
    fun start(scope: CoroutineScope, authToken: String, eventId: String) { if (job != null) return; job = scope.launch(Dispatchers.IO) { server = ServerSocket(port); while (isActive) { val socket = server!!.accept(); launch { socket.use { val input = it.getInputStream().bufferedReader(); val output = it.getOutputStream().bufferedWriter(); val request = input.readLine()?.split("|") ?: return@use; if (request.size == 3 && request[0] == authToken && request[1] == eventId) { val result = repository.confirm(eventId, request[2]); output.write(if (result.isSuccess) "OK|${result.getOrNull()}\n" else "ERROR|${result.exceptionOrNull()?.message}\n") } else output.write("ERROR|Dispositivo não autorizado.\n"); output.flush() } } } } }
    fun stop() { job?.cancel(); job = null; server?.close(); server = null }
}

suspend fun registerWithHost(host: String, authToken: String, eventId: String, qrToken: String, port: Int = 45678): Result<String> = withContext(Dispatchers.IO) { try { Socket().use { socket -> socket.connect(InetSocketAddress(host, port), 3000); val out = socket.getOutputStream().bufferedWriter(); out.write("$authToken|$eventId|$qrToken\n"); out.flush(); val response = socket.getInputStream().bufferedReader().readLine()?.split("|", limit = 2) ?: return@withContext Result.failure(IOException("Resposta vazia do anfitrião.")); if (response[0] == "OK") Result.success(response.getOrElse(1) { "Presença confirmada" }) else Result.failure(IOException(response.getOrElse(1) { "Presença não confirmada pelo anfitrião." })) } } catch (e: Exception) { Result.failure(IOException("Anfitrião indisponível; presença não confirmada.")) } }
