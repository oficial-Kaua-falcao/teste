package com.example.presencaqr.data

import android.content.Context
import androidx.room.*

@Database(entities = [Event::class, Participant::class, Attendance::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao
    abstract fun participantDao(): ParticipantDao
    abstract fun attendanceDao(): AttendanceDao
    companion object { @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "presenca_qr.db").build().also { INSTANCE = it } }
    }
}

class AttendanceRepository(private val db: AppDatabase) {
    suspend fun confirm(eventId: String, token: String): Result<String> {
        val participant = db.participantDao().byToken(token) ?: return Result.failure(IllegalArgumentException("QR Code inválido ou inexistente."))
        if (participant.eventId != eventId) return Result.failure(IllegalArgumentException("Este QR Code pertence a outro evento."))
        val existing = db.attendanceDao().find(eventId, participant.id)
        if (existing != null) return Result.failure(IllegalStateException("Presença já confirmada para este participante."))
        val inserted = db.attendanceDao().insert(Attendance(java.util.UUID.randomUUID().toString(), participant.id, eventId, token, System.currentTimeMillis()))
        return if (inserted == -1L) Result.failure(IllegalStateException("Presença já confirmada para este participante.")) else Result.success(participant.name)
    }
}
