package com.example.presencaqr.scanner

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

@Composable
fun QrScannerView(onResult: (String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current; val owner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("Ler QR Code", style = MaterialTheme.typography.titleLarge); TextButton(onClick = onBack) { Text("Voltar") } }
        if (!granted) { Text("A permissão da câmera foi negada. Conceda-a nas configurações do Android para usar o leitor.", Modifier.padding(24.dp)); Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }, Modifier.padding(24.dp)) { Text("Conceder câmera") } }
        else AndroidView(factory = { PreviewView(it) }, modifier = Modifier.fillMaxWidth().weight(1f)) { previewView ->
            val providerFuture = ProcessCameraProvider.getInstance(context); providerFuture.addListener({ val provider = providerFuture.get(); val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }; val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build(); var last = ""; var lastAt = 0L
                analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy -> val image = proxy.image; if (image != null) { BarcodeScanning.getClient().process(InputImage.fromMediaImage(image, proxy.imageInfo.rotationDegrees)).addOnSuccessListener { codes -> val value = codes.firstOrNull()?.rawValue; if (!value.isNullOrBlank() && (value != last || System.currentTimeMillis() - lastAt > 2500)) { last = value; lastAt = System.currentTimeMillis(); onResult(value) } }.addOnCompleteListener { proxy.close() } } else proxy.close() }
                try { provider.unbindAll(); provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis) } catch (_: Exception) {} }, ContextCompat.getMainExecutor(context))
        }
    }
}
