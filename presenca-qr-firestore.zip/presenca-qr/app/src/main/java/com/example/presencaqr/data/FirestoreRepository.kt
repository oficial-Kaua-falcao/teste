package com.example.presencaqr.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.toObject
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

private const val EVENTS = "events"
private const val MEMBERS = "members"
private const val ATTENDANCES = "attendances"

data class CloudUser(val id: String = "", val name: String = "")
data class CloudEvent(val id: String = "", val name: String = "", val date: String? = null, val description: String? = null, val creatorId: String = "", val createdAt: Long = 0L, val memberIds: List<String> = emptyList())
data class CloudMember(val id: String = "", val name: String = "", val joinedAt: Long = 0L)
data class CloudAttendance(val userId: String = "", val userName: String = "", val confirmedAt: Long = 0L)

class FirestoreRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun signInAndSaveName(name: String): CloudUser {
        require(name.trim().length >= 2) { "Informe um nome com pelo menos 2 caracteres." }
        val user = auth.currentUser ?: auth.signInAnonymously().await().user ?: error("Não foi possível autenticar no Firebase.")
        val profile = CloudUser(user.uid, name.trim())
        firestore.collection("users").document(user.uid).set(mapOf("name" to profile.name, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).await()
        return profile
    }

    suspend fun currentProfile(): CloudUser? {
        val user = auth.currentUser ?: return null
        val snap = firestore.collection("users").document(user.uid).get().await()
        return snap.toObject<CloudUser>()?.copy(id = user.uid)
    }

    fun observeEvents(): Flow<List<CloudEvent>> = callbackFlow {
        val registration = firestore.collection(EVENTS).addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            val current = auth.currentUser?.uid
            val list = snapshot?.documents.orEmpty().mapNotNull { it.toObject<CloudEvent>()?.copy(id = it.id) }
                .filter { current == null || it.creatorId == current || it.memberIds.contains(current) }
                .sortedByDescending { it.createdAt }
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createEvent(name: String, date: String, description: String): CloudEvent {
        val user = auth.currentUser ?: error("Usuário não autenticado.")
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val event = CloudEvent(id, name.trim(), date.ifBlank { null }, description.ifBlank { null }, user.uid, now, listOf(user.uid))
        firestore.collection(EVENTS).document(id).set(event).await()
        val profile = currentProfile()
        firestore.collection(EVENTS).document(id).collection(MEMBERS).document(user.uid).set(mapOf("name" to (profile?.name ?: "Organizador"), "joinedAt" to now)).await()
        return event
    }

    suspend fun joinEvent(eventId: String): CloudEvent {
        val user = auth.currentUser ?: error("Usuário não autenticado.")
        val eventRef = firestore.collection(EVENTS).document(eventId.trim())
        val event = eventRef.get().await().toObject<CloudEvent>()?.copy(id = eventRef.id) ?: error("Evento não encontrado. Confira o código ou QR Code.")
        val profile = currentProfile() ?: error("Cadastre seu nome antes de entrar no evento.")
        val now = System.currentTimeMillis()
        firestore.runTransaction { transaction ->
            val fresh = transaction.get(eventRef)
            transaction.update(eventRef, "memberIds", FieldValue.arrayUnion(user.uid))
            transaction.set(eventRef.collection(MEMBERS).document(user.uid), mapOf("name" to profile.name, "joinedAt" to now), SetOptions.merge())
            fresh
        }.await()
        return event
    }

    fun observeMembers(eventId: String): Flow<List<CloudMember>> = callbackFlow {
        val registration = firestore.collection(EVENTS).document(eventId).collection(MEMBERS).addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            trySend(snapshot?.documents.orEmpty().mapNotNull { it.toObject<CloudMember>()?.copy(id = it.id) }.sortedBy { it.name.lowercase() })
        }
        awaitClose { registration.remove() }
    }

    fun observeAttendances(eventId: String): Flow<List<CloudAttendance>> = callbackFlow {
        val registration = firestore.collection(EVENTS).document(eventId).collection(ATTENDANCES).addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            trySend(snapshot?.documents.orEmpty().mapNotNull { it.toObject<CloudAttendance>()?.copy(userId = it.id) })
        }
        awaitClose { registration.remove() }
    }

    suspend fun confirmMyPresence(eventId: String): Boolean {
        val user = auth.currentUser ?: error("Usuário não autenticado.")
        val profile = currentProfile() ?: error("Cadastre seu nome antes de confirmar presença.")
        val ref = firestore.collection(EVENTS).document(eventId).collection(ATTENDANCES).document(user.uid)
        return firestore.runTransaction { transaction ->
            val existing = transaction.get(ref)
            if (existing.exists()) false else { transaction.set(ref, mapOf("userName" to profile.name, "confirmedAt" to System.currentTimeMillis())); true }
        }.await()
    }
}
