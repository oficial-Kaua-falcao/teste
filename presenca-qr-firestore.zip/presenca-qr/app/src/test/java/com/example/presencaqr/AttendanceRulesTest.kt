package com.example.presencaqr

import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

class AttendanceRulesTest {
    @Test fun participantIdsAreDifferentEvenWithSameName() { val a = UUID.randomUUID().toString(); val b = UUID.randomUUID().toString(); assertNotEquals(a, b) }
    @Test fun duplicateAttendanceConstraintIsDocumented() { assertTrue("eventId + participantId possui índice único no Room", true) }
}
